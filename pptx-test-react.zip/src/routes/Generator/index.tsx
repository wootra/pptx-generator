import { useCallback, useState } from "react";
import Button from "../../ui/Button";
import { useVisualContainer } from "../../context/VisualContext";
import VisualCanvas from "../../widgets/VisualCanvas";
import Layers from "../../widgets/Layers";
import Values from "../../widgets/Values";
import UpDownButton from "../../widgets/Layers/UpDownButton";
import StringField from "../../ui/StringField";

export const Generator = () => {
  const [isCode, setIsCode] = useState(false);
  const { addText, addRadarChart, selected, download } = useVisualContainer();
  const [fileName, setFileName] = useState("pptxgen-untitled");
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState("");
  const onDownloadClick = useCallback(() => {
    setIsDownloading(true);
    setDownloadError("");
    download(fileName)
      .then(() => {
        setIsDownloading(false);
      })
      .catch((e) => {
        setDownloadError(e.message);
      });
  }, [download, fileName]);
  return (
    <div className="flex flex-col w-full h-full bg-slate-100">
      <h1 className=" bg-slate-200 p-4 flex-grow-0 flex flex-row gap-4">
        <span className="flex-grow text-3xl font-extrabold text-teal-700">
          &lt; PPT Code generator /&gt;
        </span>

        <div className="text-right text-sm basis-auto flex-0 flex flex-row justify-end items-center">
          <StringField
            label="file name"
            value={`${fileName}`}
            onChange={(txt) => setFileName(txt)}
          />
          .pptx
        </div>
        <div className="flex flex-row gap-2 flex-grow-0 flex-shrink-0 basis-10">
          <Button disabled={isDownloading} onClick={onDownloadClick}>
            download
          </Button>
          <Button onClick={() => setIsCode((state) => !state)}>
            {isCode ? "Preview" : "Code"}
          </Button>
        </div>
      </h1>
      {downloadError && <div>{downloadError}</div>}
      <div className="flex flex-row w-full h-[calc(100%-5rem)] flex-grow-0 flex-shrink">
        <ul className="basis-52 flex-0 flex flex-col gap-2 p-4 bg-slate-200">
          <Button onClick={addText}>add text</Button>
          <Button onClick={addRadarChart}>add radar chart</Button>
        </ul>
        <div className="flex-1 overflow-x-auto grid place-items-center">
          {isCode ? (
            <div className="border border-gray-100"></div>
          ) : (
            <VisualCanvas />
          )}
        </div>
        <div className="w-56 flex-grow-0 flex flex-col bg-slate-200">
          <div className="block h-[calc(50%-2rem)]">
            <h2 className="bg-green-950 text-gray-400 px-2 flex flex-row">
              <span className="flex-grow">layers</span>
              <div className="flex-grow-0 flex flex-row gap-2">
                <UpDownButton id={selected} className="text-slate-100" />
              </div>
            </h2>
            <div className="overflow-y-auto h-full">
              <Layers />
            </div>
          </div>
          <div className="block h-[calc(50%-2rem)]">
            <h2 className="bg-green-950 text-gray-400 px-2 flex-grow-0">
              values
            </h2>
            <div className="overflow-y-auto h-full">
              <Values />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Generator;
