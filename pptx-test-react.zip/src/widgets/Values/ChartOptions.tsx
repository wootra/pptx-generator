import { TextComponent } from "../../utils/addText";
import { ObjectOptions } from "./ObjectOptions";

const ChartOptions = ({
  selectedLayer,
  refreshLayers,
}: {
  selectedLayer: TextComponent;
  refreshLayers: () => void;
}) => {
  return (
    <ul className="gap-1 flex flex-col">
      <ObjectOptions
        groupName=""
        obj={selectedLayer.option}
        refreshLayers={refreshLayers}
      />
    </ul>
  );
};

export default ChartOptions;
