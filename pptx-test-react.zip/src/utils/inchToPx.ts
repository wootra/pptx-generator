import { Coords } from "./types";

const INCH_TO_PX = 100;

export const inchToPx = <T extends Coords>(obj: T) => {
  return {
    ...obj,
    x: obj.x * INCH_TO_PX,
    y: obj.y * INCH_TO_PX,
    w: obj.w * INCH_TO_PX,
    h: obj.h * INCH_TO_PX,
  };
};
