import {
  PropsWithChildren,
  createContext,
  useCallback,
  useContext,
  useMemo,
  useState,
} from "react";
import { VisualLayers } from "../utils/types";
import { createTextObj } from "../utils/addText";
import { DefaultChartRadar, createChartObj } from "../utils/addChart";
import {
  addPptxObjects,
  generateFile,
  generateSlide,
} from "../utils/generatePptx";

const useVisualContextGetSet = () => {
  const [layers, setLayers] = useState([] as VisualLayers);
  const [selected, setSelected] = useState<number | null>(null);
  const refreshLayers = useCallback(() => {
    setLayers((layers) => [...layers]);
  }, []);
  const moveUp = useCallback((id: number) => {
    setLayers((layers) => {
      const selected = layers.find((l) => l.id === id);
      if (selected) {
        const layerIndex = layers.indexOf(selected);
        if (layerIndex === 0) return layers;
        return [
          ...layers.slice(0, layerIndex - 1),
          selected,
          ...layers.slice(layerIndex - 1).filter((layer) => layer.id !== id),
        ];
      }
      return layers;
    });
  }, []);

  const moveDown = useCallback((id: number) => {
    setLayers((layers) => {
      const selected = layers.find((l) => l.id === id);
      if (selected) {
        const layerIndex = layers.indexOf(selected);
        if (layerIndex === layers.length - 1) return layers;
        return [
          ...layers.slice(0, layerIndex + 2).filter((layer) => layer.id !== id),
          selected,
          ...layers.slice(layerIndex + 2),
        ];
      }
      return layers;
    });
  }, []);
  const toggleSelected = useCallback(
    (id: number) => {
      console.log("selected:", id);
      if (selected !== id) {
        setSelected(id);
      } else {
        setSelected(null);
      }
    },
    [selected]
  );
  const selectedLayer = useMemo(() => {
    return layers.find((layer) => layer.id === selected);
  }, [layers, selected]);

  const deleteLayer = useCallback((id: number) => {
    setLayers((layers) => layers.filter((layer) => layer.id !== id));
  }, []);
  const addText = useCallback(() => {
    setLayers((layers) => [
      ...layers,
      createTextObj("default text", { x: 1, y: 0.5, w: 8, h: 1, fontSize: 30 }),
    ]);
  }, []);
  const addRadarChart = useCallback(() => {
    setLayers((layers) => [
      ...layers,
      createChartObj(DefaultChartRadar, { x: 1, y: 1, w: 8, h: 3 }),
    ]);
  }, []);
  const download = useCallback(
    (fileName: string) => {
      const { instance, slide } = generateSlide(null);
      addPptxObjects(slide, layers);
      return generateFile(instance, fileName);
    },
    [layers]
  );
  return {
    layers,
    addText,
    addRadarChart,
    deleteLayer,
    selected,
    selectedLayer,
    toggleSelected,
    refreshLayers,
    moveUp,
    moveDown,
    download,
  };
};
type VisualContextType = ReturnType<typeof useVisualContextGetSet>;

const VisualContext = createContext<VisualContextType>({} as VisualContextType);

export const VisualContainerProvider = ({ children }: PropsWithChildren) => {
  const providerValues = useVisualContextGetSet();

  return (
    <VisualContext.Provider value={providerValues}>
      {children}
    </VisualContext.Provider>
  );
};

export const useVisualContainer = () => {
  return useContext(VisualContext);
};
