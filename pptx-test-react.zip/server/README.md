# pptx generator POC application guide(client)

below documentation is the example for server side.
for the client side, move to [CLIENT-SIDE-EXAMPLE](..//README.md)
