import { useEffect, useRef } from "react";
import { useVisualContainer } from "../../context/VisualContext";
import { drawLayers } from "./drawLayers";
import { drawSelected } from "./drawSelected";

const VisualCanvas = () => {
  const { layers, selected, selectedLayer } = useVisualContainer();
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    if (c) {
      const ctx = c.getContext("2d");
      if (!ctx) return;
      ctx.clearRect(0, 0, 1000, 563); // width: 10" , height: 5.63"
      drawLayers(ctx, layers, selected);
      drawSelected(ctx, selectedLayer);
    }
  }, [layers, selected, selectedLayer]);
  return (
    <canvas
      ref={ref}
      className="border border-gray-400 shadow-lg"
      width={1000}
      height={560}
    />
  );
};

export default VisualCanvas;
